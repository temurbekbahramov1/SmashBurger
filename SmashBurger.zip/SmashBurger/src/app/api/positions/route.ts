import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const positions = await db.jobPosition.findMany({
      include: {
        branch: true,
        _count: {
          select: {
            applications: true
          }
        }
      },
      orderBy: {
        title: 'asc'
      }
    })

    return NextResponse.json(positions)
  } catch (error) {
    console.error('Error fetching positions:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, branchId } = body

    if (!title || !branchId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const position = await db.jobPosition.create({
      data: {
        title,
        branchId
      },
      include: {
        branch: true
      }
    })

    return NextResponse.json(position)
  } catch (error) {
    console.error('Error creating position:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}