import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const BOT_TOKEN = '8335706213:AAHByiwNbOHY-9anstn7mICaXfZW-ZbXKCk'
const CHAT_ID = '-1002971074527'

async function sendToTelegram(applicationData: any) {
  const message = `
🆕 Yangi ish arizasi!

👤 Ism: ${applicationData.fullName}
📞 Telefon: ${applicationData.phone}
🏢 Filial: ${applicationData.branch.name}
💼 Lavozim: ${applicationData.position.title}
⏰ Smena: ${applicationData.shift.name}
📍 Manzil: ${applicationData.branch.location}

${applicationData.notes ? `📝 Qo'shimcha: ${applicationData.notes}` : ''}
⏰ Vaqt: ${new Date(applicationData.timestamp).toLocaleString('uz-UZ')}
  `.trim()

  try {
    const response = await fetch(
      `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text: message,
          parse_mode: 'HTML'
        }),
      }
    )

    if (!response.ok) {
      throw new Error('Failed to send message to Telegram')
    }

    return await response.json()
  } catch (error) {
    console.error('Error sending to Telegram:', error)
    throw error
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { branchId, positionId, shiftId, fullName, phone, notes } = body

    // Validate required fields
    if (!branchId || !positionId || !shiftId || !fullName || !phone) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Get related data
    const branch = await db.branch.findUnique({
      where: { id: branchId }
    })

    const position = await db.jobPosition.findUnique({
      where: { id: positionId }
    })

    const shift = await db.workShift.findUnique({
      where: { id: shiftId }
    })

    if (!branch || !position || !shift) {
      return NextResponse.json(
        { error: 'Invalid branch, position, or shift' },
        { status: 400 }
      )
    }

    // Save application to database
    const application = await db.jobApplication.create({
      data: {
        fullName,
        phone,
        notes: notes || null,
        branchId,
        positionId,
        shiftId
      },
      include: {
        branch: true,
        position: true,
        shift: true
      }
    })

    // Send to Telegram
    await sendToTelegram(application)

    return NextResponse.json({ 
      success: true, 
      applicationId: application.id 
    })

  } catch (error) {
    console.error('Error processing job application:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const applications = await db.jobApplication.findMany({
      include: {
        branch: true,
        position: true,
        shift: true
      },
      orderBy: {
        timestamp: 'desc'
      }
    })

    return NextResponse.json(applications)
  } catch (error) {
    console.error('Error fetching applications:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}