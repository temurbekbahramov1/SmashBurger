'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { MapPin, Clock, User, Phone, MessageSquare, CheckCircle } from 'lucide-react'

interface Branch {
  id: string
  name: string
  location: string
  mapsUrl: string
  positions: JobPosition[]
}

interface JobPosition {
  id: string
  title: string
  branchId: string
}

interface WorkShift {
  id: string
  name: string
  startTime: string
  endTime: string
}

interface FormData {
  branchId: string
  positionId: string
  shiftId: string
  fullName: string
  phone: string
  notes: string
}

const initialFormData: FormData = {
  branchId: '',
  positionId: '',
  shiftId: '',
  fullName: '',
  phone: '',
  notes: ''
}

export default function JobApplication() {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [branches, setBranches] = useState<Branch[]>([])
  const [positions, setPositions] = useState<JobPosition[]>([])
  const [shifts, setShifts] = useState<WorkShift[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [branchesRes, positionsRes, shiftsRes] = await Promise.all([
        fetch('/api/branches'),
        fetch('/api/positions'),
        fetch('/api/shifts')
      ])

      const branchesData = await branchesRes.json()
      const positionsData = await positionsRes.json()
      const shiftsData = await shiftsRes.json()

      setBranches(branchesData)
      setPositions(positionsData)
      setShifts(shiftsData)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const steps = [
    { title: 'Filial tanlang', icon: MapPin },
    { title: 'Manzil', icon: MapPin },
    { title: 'Lavozim', icon: User },
    { title: 'Ish grafigi', icon: Clock },
    { title: 'Ariza', icon: MessageSquare }
  ]

  const handleBranchSelect = (branchId: string) => {
    setFormData(prev => ({ ...prev, branchId, positionId: '' }))
  }

  const handlePositionSelect = (positionId: string) => {
    setFormData(prev => ({ ...prev, positionId }))
  }

  const handleShiftSelect = (shiftId: string) => {
    setFormData(prev => ({ ...prev, shiftId }))
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    
    try {
      const response = await fetch('/api/job-application', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setIsSubmitted(true)
      } else {
        throw new Error('Failed to submit application')
      }
    } catch (error) {
      console.error('Error submitting application:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const resetForm = () => {
    setFormData(initialFormData)
    setCurrentStep(0)
    setIsSubmitted(false)
  }

  const getSelectedBranch = () => branches.find(b => b.id === formData.branchId)
  const getSelectedPosition = () => positions.find(p => p.id === formData.positionId)
  const getSelectedShift = () => shifts.find(s => s.id === formData.shiftId)

  const canProceedToNext = () => {
    switch (currentStep) {
      case 0: return formData.branchId !== ''
      case 1: return true
      case 2: return formData.positionId !== ''
      case 3: return formData.shiftId !== ''
      case 4: return formData.fullName.trim() !== '' && formData.phone.trim() !== ''
      default: return false
    }
  }

  const renderStepContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      )
    }

    if (isSubmitted) {
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-8"
        >
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">✅ Arizangiz yuborildi</h2>
          <p className="text-gray-600 mb-6">Tez orada siz bilan bog'lanamiz</p>
          <Button onClick={resetForm} variant="outline">
            Yangi ariza yuborish
          </Button>
        </motion.div>
      )
    }

    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Filialni tanlang</h3>
            <div className="grid gap-3">
              {branches.map((branch) => (
                <motion.div
                  key={branch.id}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card
                    className={`cursor-pointer transition-all ${
                      formData.branchId === branch.id
                        ? 'ring-2 ring-blue-500 bg-blue-50'
                        : 'hover:shadow-md'
                    }`}
                    onClick={() => handleBranchSelect(branch.id)}
                  >
                    <CardContent className="p-4">
                      <h4 className="font-medium">{branch.name}</h4>
                      <p className="text-sm text-gray-600">{branch.location}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )

      case 1:
        const selectedBranch = getSelectedBranch()
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Manzil</h3>
            {selectedBranch && (
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-2">{selectedBranch.name}</h4>
                  <p className="text-sm text-gray-600 mb-3">{selectedBranch.location}</p>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => window.open(selectedBranch.mapsUrl, '_blank')}
                  >
                    <MapPin className="w-4 h-4 mr-2" />
                    Xaritada ko'rish
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )

      case 2:
        const availablePositions = positions.filter(p => p.branchId === formData.branchId)
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Lavozimni tanlang</h3>
            <div className="grid grid-cols-2 gap-3">
              {availablePositions.map((position) => (
                <motion.div
                  key={position.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Card
                    className={`cursor-pointer transition-all ${
                      formData.positionId === position.id
                        ? 'ring-2 ring-blue-500 bg-blue-50'
                        : 'hover:shadow-md'
                    }`}
                    onClick={() => handlePositionSelect(position.id)}
                  >
                    <CardContent className="p-3 text-center">
                      <p className="font-medium text-sm">{position.title}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Ish grafigini tanlang</h3>
            <div className="grid grid-cols-2 gap-3">
              {shifts.map((shift) => (
                <motion.div
                  key={shift.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Card
                    className={`cursor-pointer transition-all ${
                      formData.shiftId === shift.id
                        ? 'ring-2 ring-blue-500 bg-blue-50'
                        : 'hover:shadow-md'
                    }`}
                    onClick={() => handleShiftSelect(shift.id)}
                  >
                    <CardContent className="p-3 text-center">
                      <p className="font-medium text-sm">{shift.name}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-4">Ariza ma'lumotlari</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">To'liq ismingiz</label>
                <Input
                  value={formData.fullName}
                  onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                  placeholder="Ism familiya"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Telefon raqamingiz</label>
                <Input
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+998 XX XXX XX XX"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Qo'shimcha izoh (ixtiyoriy)</label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="Qo'shimcha ma'lumotlar..."
                  rows={3}
                />
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <h1 className="text-2xl font-bold mb-2">Smash Burger</h1>
          <Button
            variant="link"
            className="text-blue-600 p-0 h-auto"
            onClick={() => window.open('https://maps.app.goo.gl/SPPh8BqZfauge4gX9?g_st=ac', '_blank')}
          >
            <MapPin className="w-4 h-4 mr-1" />
            Manzilni ko'rish
          </Button>
        </motion.div>

        {/* Progress Steps */}
        <div className="flex justify-between mb-6">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <div key={index} className="flex flex-col items-center flex-1">
                <motion.div
                  animate={{
                    scale: index <= currentStep ? 1.1 : 1,
                    backgroundColor: index <= currentStep ? '#3B82F6' : '#E5E7EB'
                  }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium mb-1 ${
                    index <= currentStep ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                >
                  {index + 1}
                </motion.div>
                <p className="text-xs text-center text-gray-600">{step.title}</p>
              </div>
            )
          })}
        </div>

        {/* Main Content */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                {renderStepContent()}
              </motion.div>
            </AnimatePresence>
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        {!isSubmitted && (
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(prev => Math.max(0, prev - 1))}
              disabled={currentStep === 0}
              className="flex-1"
            >
              Orqaga
            </Button>
            {currentStep < steps.length - 1 ? (
              <Button
                onClick={() => setCurrentStep(prev => prev + 1)}
                disabled={!canProceedToNext()}
                className="flex-1"
              >
                Keyingi
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={!canProceedToNext() || isSubmitting}
                className="flex-1"
              >
                {isSubmitting ? 'Yuborilmoqda...' : 'Arizani yuborish'}
              </Button>
            )}
          </div>
        )}

        {/* Summary */}
        {currentStep > 0 && !isSubmitted && (
          <Card className="mt-4">
            <CardContent className="p-3">
              <h4 className="font-medium text-sm mb-2">Tanlanganlar:</h4>
              <div className="space-y-1 text-xs">
                {getSelectedBranch() && (
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{getSelectedBranch()?.name}</Badge>
                  </div>
                )}
                {getSelectedPosition() && (
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{getSelectedPosition()?.title}</Badge>
                  </div>
                )}
                {getSelectedShift() && (
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{getSelectedShift()?.name}</Badge>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}