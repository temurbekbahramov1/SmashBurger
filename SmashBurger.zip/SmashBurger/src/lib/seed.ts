import { db } from '@/lib/db'

async function main() {
  // Create branches
  const smashBurgerChilonzor = await db.branch.create({
    data: {
      name: 'Smash Burger Chilonzor',
      location: 'Chilonzor district',
      mapsUrl: 'https://maps.app.goo.gl/SPPh8BqZfauge4gX9?g_st=ac'
    }
  })

  const smashBurgerSergeli = await db.branch.create({
    data: {
      name: 'Smash Burger Sergeli',
      location: 'Sergeli district',
      mapsUrl: 'https://maps.app.goo.gl/SPPh8BqZfauge4gX9?g_st=ac'
    }
  })

  const bulochkaSex = await db.branch.create({
    data: {
      name: 'Bulochka Sex',
      location: 'City center',
      mapsUrl: 'https://maps.app.goo.gl/SPPh8BqZfauge4gX9?g_st=ac'
    }
  })

  // Create positions for Smash Burger Chilonzor
  await db.jobPosition.createMany({
    data: [
      { title: 'Afitsant', branchId: smashBurgerChilonzor.id },
      { title: 'Barista', branchId: smashBurgerChilonzor.id },
      { title: 'Farrosh', branchId: smashBurgerChilonzor.id },
      { title: 'Oshpaz', branchId: smashBurgerChilonzor.id },
      { title: 'Kassir', branchId: smashBurgerChilonzor.id }
    ]
  })

  // Create positions for Smash Burger Sergeli
  await db.jobPosition.createMany({
    data: [
      { title: 'Afitsant', branchId: smashBurgerSergeli.id },
      { title: 'Barista', branchId: smashBurgerSergeli.id },
      { title: 'Farrosh', branchId: smashBurgerSergeli.id },
      { title: 'Oshpaz', branchId: smashBurgerSergeli.id },
      { title: 'Kassir', branchId: smashBurgerSergeli.id }
    ]
  })

  // Create positions for Bulochka Sex
  await db.jobPosition.createMany({
    data: [
      { title: 'Farrosh', branchId: bulochkaSex.id },
      { title: 'Haydovchi', branchId: bulochkaSex.id },
      { title: 'Pishiruvchi', branchId: bulochkaSex.id }
    ]
  })

  // Create work shifts
  await db.workShift.createMany({
    data: [
      { name: '08:00 – 16:00', startTime: '08:00', endTime: '16:00' },
      { name: '16:00 – 23:00', startTime: '16:00', endTime: '23:00' },
      { name: '18:00 – 24:00', startTime: '18:00', endTime: '24:00' },
      { name: '11:00 – 23:00', startTime: '11:00', endTime: '23:00' },
      { name: '12:00 – 24:00', startTime: '12:00', endTime: '24:00' }
    ]
  })

  console.log('Database seeded successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })